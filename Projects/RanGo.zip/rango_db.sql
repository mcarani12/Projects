-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 06, 2021 at 04:36 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rango_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_tbl`
--

CREATE TABLE `admin_tbl` (
  `Admin_ID` int(11) NOT NULL,
  `Code` varchar(10) NOT NULL,
  `Password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_tbl`
--

INSERT INTO `admin_tbl` (`Admin_ID`, `Code`, `Password`) VALUES
(1, '1111', 'admin1111');

-- --------------------------------------------------------

--
-- Table structure for table `members_tbl`
--

CREATE TABLE `members_tbl` (
  `Member_ID` int(11) NOT NULL,
  `Full_Name` varchar(25) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Phone_Number` varchar(15) NOT NULL,
  `Username` varchar(15) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `members_tbl`
--

INSERT INTO `members_tbl` (`Member_ID`, `Full_Name`, `Email`, `Phone_Number`, `Username`, `Password`, `Image`) VALUES
(11, 'Mark Amir Carani', 'markamircarani@outlook.com', '99687179', 'mark', '$2y$10$XoK33Xv3VBKZC6VQTzTQSOEFyxowTT9xAD7kuZC3lB77MfVmVjIuy', 'Profile_Images/FB_IMG_1595962601123.jpg'),
(12, 'Mark Amir Carani Haleb', 'mcarani5@outlook.com', '99687177', 'mark2', '$2y$10$EEk54REn35u/.Qkf/AgGxenUmCKLyQKfDLCDoT2Z/z5I.WoDdDiWS', 'Profile_Images/FB_IMG_1607381176859.jpg'),
(13, 'Joe Cremona', 'joecremona@gmail.com', '77665544', 'joe', '$2y$10$.eCAFqZKyVZhT6cbDYvjROiEJhohhQ1Fer40ZdvNcGpEkzkqD1Bj.', 'Profile_Images/received_440577366624702.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `shoes_tbl`
--

CREATE TABLE `shoes_tbl` (
  `ID` int(11) NOT NULL,
  `Brand` varchar(15) NOT NULL,
  `Name` varchar(15) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Price` int(11) NOT NULL,
  `Image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `shoes_tbl`
--

INSERT INTO `shoes_tbl` (`ID`, `Brand`, `Name`, `Gender`, `Price`, `Image`) VALUES
(4, 'Nike', 'React', 'Male', 100, 'Profile_Images/React.png'),
(5, 'Jordan', '1s', 'Male', 140, 'Profile_Images/1s.png'),
(6, 'Nike', 'Air Max 97', 'Male', 180, 'Profile_Images/Air Max 97.png'),
(8, 'Under Armour', 'Hovr Phantom', 'Male', 167, 'Profile_Images/Hovr Phantom.png'),
(10, 'Under Armour', 'Hovr Sonic 5', 'Male', 167, 'Profile_Images/Hovr Sonic 3.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  ADD PRIMARY KEY (`Admin_ID`);

--
-- Indexes for table `members_tbl`
--
ALTER TABLE `members_tbl`
  ADD PRIMARY KEY (`Member_ID`);

--
-- Indexes for table `shoes_tbl`
--
ALTER TABLE `shoes_tbl`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  MODIFY `Admin_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `members_tbl`
--
ALTER TABLE `members_tbl`
  MODIFY `Member_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `shoes_tbl`
--
ALTER TABLE `shoes_tbl`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
