<?php
    session_start(); 
?>
<!DOCTYPE html>
<html>
    <head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		<title>Registration/Log In Form</title>
		<link rel="stylesheet" href="style.css"/>
    </head>

    <body style="background-color: #e6e6e6;">	
		<?php include("nav1.php"); ?>
		
		<h1 class="bold">Registration Form</h1>
		<p class="bold">Enter your details below to become a member of RanGo!</p>
		<form enctype="multipart/form-data" action="index.php" method="post">
			<div class="row">
				<div class="col"><label>Name</label>				<input type="text" name="Name" class="form-control" placeholder="John"></div>
				<div class="col"><label>Last Name</label>			<input type="text" name="Last_Name" class="form-control" placeholder="Blake"></div>
			</div>
			<div class="row">
				<div class="col"><label>Email</label>				<input type="email" name="Email" class="form-control" placeholder="johnblake@gmail.com"></div>
				<div class="col"><label>Phone Number</label>		<input type="text" name="Phone_Number" class="form-control" placeholder="+35699887766"></div>
			</div>
			<div class="row">
				<div class="col"><label>Username</label>			<input type="text" name="Username" class="form-control" placeholder="johnblake77"></div>
				<div class="col"><label>Password</label>			<input type="password" name="Password" class="form-control" placeholder="Password"></div>
			</div>
			<div class="form-group"><label>Profile Picture</label>	<input type="file" name="Image" class="form-control-file"></div>
			<input type="submit" value="Register" name="Register" class="btn btn-primary">
		</form>
		
		<br>
		
		<h1 class="bold">Log In Form</h1>
		<p class="bold">Log in to view our latest arrivals!</p>
		<form action="index.php" method="post">
			<div class="form-group"><label>Username:</label>	<input type="text" name="Log_In_Username" class="form-control" placeholder="Username"></div>
			<div class="form-group"><label>Password:</label>	<input type="password" name="Log_In_Password" class="form-control" placeholder="Password"></div>
			<input type="submit" value="Log In" name="Log_In" class="btn btn-primary">
		</form>
		
		<?php
			require_once("connection.php");
			
			if(isset($_POST['Register'])){ 
				$Full_Name = trim($_POST['Name']). ' ' . trim($_POST['Last_Name']);
				$Email = $_POST['Email']; 
				$Phone_Number = $_POST['Phone_Number']; 
				$Username = $_POST['Username']; 
				$Password = $_POST['Password'];
											
				if(empty($_POST['Name']) || empty($_POST['Last_Name']) || empty($Email) || empty($Phone_Number) || empty($Username) || empty($Password)){ 
					echo "<p>Fill in the form properly please</p>"; 
				}
				else{
					$Upload = 'Profile_Images/'.$_FILES['Image']['name'];
					if(move_uploaded_file($_FILES['Image']['tmp_name'], $Upload)){					
						$Username = mysqli_real_escape_string($Connection, $Username);
						$Email = mysqli_real_escape_string($Connection, $Email);
						$Phone_Number = mysqli_real_escape_string($Connection, $Phone_Number);

						$Check_Username_Query = "SELECT COUNT(*) 
												 FROM members_tbl WHERE Username = '$Username' OR Email = '$Email' OR Phone_Number = '$Phone_Number'"; 

						$Username_Result = mysqli_query($Connection, $Check_Username_Query)
							or die("Error in query: ".mysqli_error($Connection)); 
						
						$Row = mysqli_fetch_row($Username_Result);
						$Count = $Row[0];

						if($Count > 0){ 
							echo "<p>Unfortunately, the username, email, or phone number have already been taken</p>
								  <p>Please, go back and select another username or use a different email or phone number</p>";
						}
						else{
							echo "<p>Your registration was successful</p>
								  <p>Enjoy all the benefits of being a RanGo member!</p>
								  <p>Now log into your new account</p>";
							
							$Full_Name = mysqli_real_escape_string($Connection, $Full_Name);
							$Hashed_Password = password_hash($Password, PASSWORD_DEFAULT); 
							
							$Save_Details_Query = "INSERT INTO members_tbl (Full_Name, Email, Phone_Number, Username, Password, Image) 
												   VALUES ('$Full_Name', '$Email', '$Phone_Number', '$Username', '$Hashed_Password', '$Upload')"; 

							$Save_Details_Result = mysqli_query($Connection, $Save_Details_Query)
								or die("Error in query: ".mysqli_error($Connection));
						}					
					}else{
						echo "<p>Problem uploading profile image</p>";
					}				
				}
			}
			elseif(isset($_POST['Log_In'])){
				$Log_In_Username = $_POST['Log_In_Username'];
				$Log_In_Password = $_POST['Log_In_Password'];
				
				if(empty($Log_In_Username) || empty($Log_In_Password)){ 
					echo "<p>Enter your credentials please</p>"; 
				}
				else{
                    $Check_Credentials = "SELECT COUNT(*) 
										  FROM members_tbl WHERE Username = '$Log_In_Username' OR Phone_Number = '$Log_In_Username' AND Password = '$Log_In_Password'"; 

                    $Credentials_Result = mysqli_query($Connection, $Check_Credentials)
                        or die("Error in query: ".mysqli_error($Connection)); 
                    
                    $Row = mysqli_fetch_row($Credentials_Result);
                    $Count = $Row[0];
					
					if($Count > 0){ 
						$_SESSION['Log_In_Username'] = $Log_In_Username;
                        echo "<p>You have successfully logged in!</p>
							  <p>Select which section you would like to visit below</p>";?>
							  <a href="men.php">Men</a>
							  <a href="women.php">Women</a>
							  <?php
                    }
                    else{
                        echo "<p>Unsuccessful log in</p>
							  <p>Try again please</p>";
                    }
				}
			}
		?>
		
		<?php include("footer.php"); ?>
		
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    </body>
</html>