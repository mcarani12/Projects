<!DOCTYPE html>
<html>
    <head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <title>Administration</title>
		<link rel="stylesheet" href="style.css"/>
    </head>

    <body style="background-color: #e6e6e6;">
		<?php include("nav1.php"); ?>
		
		<div class="a">
			<h1 class="bold">Administrator Log In</h1>
			<p class="bold">Enter your correct credentials to modify the website</p>
			<form action="admin.php" method="post">
				<div class="form-group"><label>Code:</label>	<input type="text" name="Code" class="form-control" placeholder="5555"></div>
				<div class="form-group"><label>Password:</label><input type="password" name="Password" class="form-control" placeholder="Password"></div>
				<input type="submit" value="Enter" name="Enter" class="btn btn-primary">
			</form>
		</div>
		
		<br>
        
		<div class="b">
			<h1 class="bold">Add Items</h1>
			<p class="bold">Insert our latest arrivals onto our website</p>
			<form enctype="multipart/form-data" action="admin.php" method="post">
				<div class="form-group"><label>Brand:</label> 	<input type="text" name="Brand" class="form-control" placeholder="Nike"></div>
				<div class="form-group"><label>Name:</label> 	<input type="text" name="Name" class="form-control" placeholder="Air Max 95"></div>
				<div class="form-group"><label>Gender:</label> 	<input type="text" name="Gender" class="form-control" placeholder="Male"></div>
				<div class="form-group"><label>Price:</label> 	<input type="text" name="Price" class="form-control" placeholder="149"></div>
				<div class="form-group"><label>Image:</label>	<input type="file" name="Image" class="form-control-file"></div>
				<input type="submit" value="Add Item" name="Add_Item" class="btn btn-primary">
			</form>
		</div>
		
		<br>
		
		<div class="b">
			<h1 class="bold">Delete Items</h1>
			<p class="bold">Remove old items by inserting the shoe name</p>
			<form action="admin.php" method="post">
				<div class="form-group"><label>Shoe Name:</label> 	<input type="text" name="Shoe_Name_Delete" class="form-control" placeholder="Air Jordan 1 Blue"></div>
				<input type="submit" value="Remove" name="Remove" class="btn btn-primary">
			</form>
		</div>
		
		<br>
		
		<div class="b">
			<h1 class="bold">Update Price</h1>
			<p class="bold">Update the price of new and old items</p>
			<form action="admin.php" method="post">
				<div class="form-group"><label>Shoe Name:</label> 	<input type="text" name="Shoe_Name_Update" class="form-control" placeholder="Lebron 12s"></div>
				<div class="form-group"><label>New Price:</label> 	<input type="text" name="New_Price" class="form-control" placeholder="100"></div>
				<input type="submit" value="Update Price" name="Update" class="btn btn-primary">
			</form>
		</div>
		
		<?php
			require_once("connection.php");
			if(isset($_POST['Enter'])){
				if(empty($_POST['Code']) || empty($_POST['Password'])){
					echo "<p>Please enter all fields</p>"; 
				}
				else{
					$Code = $_POST['Code'];
					$Password = $_POST['Password'];
					
					$Check_Credentials = "SELECT COUNT(*) 
										  FROM admin_tbl 
										  WHERE Code = '$Code' AND Password = '$Password'"; 
										  
					$Credentials_Result = mysqli_query($Connection, $Check_Credentials)
                        or die("Error in query: ".mysqli_error($Connection)); 
						
					$Row = mysqli_fetch_row($Credentials_Result);
                    $Count = $Row[0];
					
					if($Count > 0){ 
                        echo "<p>You have successfully logged in!</p>
							  <p>Please update the products for our online shop</p>";?>
							  <style>
							  .a{
								  visibility: hidden;
							  }
							  
							  .b{
								  visibility: visible;
							  }
							  </style><?php
                    }
                    else{
						echo "<p>Please leave if you do not have authorised access</p>"; 
					}
				}
			}
			elseif(isset($_POST['Add_Item'])){
				if(empty($_POST['Brand']) || empty($_POST['Name']) || empty($_POST['Gender']) || empty($_POST['Price'])){
					echo "<p>Please enter all fields</p>"; 
				}
				else{
					$Upload = 'Profile_Images/'.$_FILES['Image']['name'];
					if(move_uploaded_file($_FILES['Image']['tmp_name'], $Upload)){
						$Brand = $_POST['Brand'];
						$Name = $_POST['Name'];
						$Gender = $_POST['Gender'];
						$Price = $_POST['Price'];
						
						$Add_Items = "INSERT INTO shoes_tbl (Brand, Name, Gender, Price, Image) 
									  VALUES ('$Brand', '$Name', '$Gender', '$Price', '$Upload')"; 
								  
						$Add_Items_Result = mysqli_query($Connection, $Add_Items)
								or die("Error in query: ".mysqli_error($Connection));
					}
					else{
						echo "<p>Problem uploading shoe image</p>";
					}					
				}
			}
			elseif(isset($_POST['Remove'])){
				if(empty($_POST['Shoe_Name_Delete'])){
					echo "<p>Please enter the shoe name</p>";
				}
				else{
					$Shoe_Name_Delete = $_POST['Shoe_Name_Delete'];
					$Delete_Item = "DELETE
									FROM shoes_tbl
									WHERE Name = '$Shoe_Name_Delete'";
									
					$Delete_Item_Result = mysqli_query($Connection, $Delete_Item)
								or die("Error in query: ".mysqli_error($Connection));
				}
			}
			elseif(isset($_POST['Update'])){
				if(empty($_POST['Shoe_Name_Update']) || empty($_POST['New_Price'])){
					echo "<p>Please enter the shoe name and new price</p>";
				}
				else{
					$Shoe_Name_Update = $_POST['Shoe_Name_Update'];
					$New_Price = $_POST['New_Price'];
					$Update_Price = "UPDATE shoes_tbl
									 SET Price = '$New_Price'
									 WHERE Name = '$Shoe_Name_Update'";
					
					$Update_Price_Result = mysqli_query($Connection, $Update_Price)
								or die("Error in query: ".mysqli_error($Connection));
				}
			}
		?>	
		
		<?php include("footer.php"); ?>
		
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	</body>
</html>