<div style="display: flex; justify-content: center;">
	<div style="display: grid; grid-template-columns: 300px 300px 300px; justify-content: space-around; width: 85%;">
	<?php
		$Get_Mens_Shoe_Image = "SELECT * 
								FROM shoes_tbl
								WHERE Gender = '$Gender'
								ORDER BY Price desc";

		$Get_Mens_Shoe_Image_Result = mysqli_query($Connection, $Get_Mens_Shoe_Image)
			or die("Error in query: ". mysqli_error($Connection));
			
		while ($row = mysqli_fetch_assoc($Get_Mens_Shoe_Image_Result)){
			?>
				<div style="display: flex; justify-content: center; padding: 25px 0px;">
					<div>
						<img src="<?php echo $row['Image']; ?>" width='275px' height='250px' style="border-radius: 16px;"/></br>
					</div>
					<div style="padding-left: 30px; padding-top: 30px;">
						<p class="bold" style="font-size: 30px;"><?php echo "$row[Brand]"; ?></p>
						<p class="bold" style="font-size: 30px;"><?php echo "$row[Name]"; ?></p>
						<p class="bold" style="font-size: 30px;"><?php echo "€$row[Price]"; ?></p>
						<form action="<?php echo $Gender2; ?>.php" method="post">
							<input type="submit" value="Add to cart" name="Cart" class="btn btn-primary">
						</form>
						<?php
							if(isset($_POST['Cart'])){
								if(is_null($_SESSION['Total'])){
									$_SESSION['Total'] = 0;
								}
								$_SESSION['Total'] += intval($row['Price']);
							}
						?>
					</div>
				</div>
			<?php			
		}
	?>
	</div>
</div>