<nav class="navbar navbar-expand-lg navbar-dark bg-secondary" style="height: 160px; justify-content: center;">
	<h1>Mark Amir Carani 2021 &copy;</h1>
</nav>