<nav class="navbar navbar-expand-lg navbar-dark bg-secondary" style="height: 160px;">
	<a class="navbar-brand" href="#">
		<img src="RanGo_Logo.png" width="130" height="100" alt="">
	</a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	</button>
	<div class="collapse navbar-collapse" id="navbarNav">
		<ul class="navbar-nav">
			<li class="nav-item">
				<a class="nav-link" href="men.php">Men</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="women.php">Women</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="checkout.php">Checkout</a>
			</li>
		</ul>		
	</div>
	<ul class="navbar-nav">
		<li class="nav-item" style="padding-right: 30px;">
			<button class="btn btn-outline-dark" type="button">
				<a class="nav-link" href="logout.php">Logout</a>
			</button>			
		</li>
	</ul>
	<?php	
		$Get_Profile_Image_Query = "SELECT Image 
									FROM members_tbl
									WHERE Username LIKE '$_SESSION[Log_In_Username]'";

		$Path_Result = mysqli_query($Connection, $Get_Profile_Image_Query)
			or die("Error in query: ". mysqli_error($Connection));

		while ($row = mysqli_fetch_assoc($Path_Result)){
			?>
			<img src="<?php echo $row['Image']; ?>" width='150px' height='150px'/></br>
			<?php
		}
	?>
</nav>