<?php
  session_start();
  
  unset($_SESSION['Log_In_Username']);
  unset($_SESSION['Total']);
  session_destroy();
  
  header("Location: index.php");
?>