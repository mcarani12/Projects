<?php
	$Connection = mysqli_connect("localhost", "root", "", "rango_db");
	if (mysqli_connect_errno()){
	die("Error: Could not connect to database. 
		 Please try again later");
	}
?>