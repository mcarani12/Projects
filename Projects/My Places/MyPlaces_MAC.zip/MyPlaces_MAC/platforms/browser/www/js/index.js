document.addEventListener('deviceready', onDeviceReady);

function onDeviceReady() {
    console.log("Index is ready");
    loadPlaces();
}

function loadPlaces(){
    var allPlaces = JSON.parse(localStorage.getItem("allPlaces"));

    const ionList = document.createElement('ion-list');
    
    if (allPlaces != null && allPlaces.length > 0) {
        allPlaces.forEach(addPlaces);

        function addPlaces(item, index) {
            var icon = ``;
            if (item.category == "Restaurant"){
                icon = `<ion-icon name="restaurant-outline"></ion-icon>`;
            }
            else if(item.category == "Shop"){
                icon = `<ion-icon name="bag-handle-outline"></ion-icon>`;
            }
            else if(item.category == "Information"){
                icon = `<ion-icon name="information-outline"></ion-icon>`;
            }
            else if(item.category == "Leisure"){
                icon = `<ion-icon name="sunny-outline"></ion-icon>`;
            }       

            var favPlaces = JSON.parse(localStorage.getItem("favPlaces"));
            if (favPlaces == null)
                favPlaces = [];
    
            if(favPlaces.includes(index)){
                var star = "star";
            }
            else{
                var star = "star-outline";
            }

            if (star == "star"){
                ionList.innerHTML += `     
                <ion-item-sliding>                
                    <ion-item lines="full" data="${index}">
                        <ion-buttons slot="start">
                            <ion-button onClick="presentModal(${index})">
                                <ion-label>
                                    ${icon} ${item.title}
                                </ion-label>
                            <ion-button>
                        </ion-buttons>

                        <ion-buttons slot="end">
                            <ion-button onClick="undoFavourite(${index})">
                                <ion-icon id="star${index}" name="${star}" color="warning"></ion-icon>
                            </ion-button> 
                        </ion-buttons>
                    </ion-item>
                
                    <ion-item-options side="end">
                        <ion-item-option onClick="deletePlace(${index})" color="danger">Delete</ion-item-option>
                    </ion-item-options>
                </ion-item-sliding>
            `;   
            }
            else{
                ionList.innerHTML += `     
                <ion-item-sliding>                
                    <ion-item lines="full" data="${index}">                               
                    <ion-buttons slot="start">
                        <ion-button onClick="presentModal(${index})">
                            <ion-label>
                                ${icon} ${item.title}
                            </ion-label>
                        <ion-button>
                    </ion-buttons>

                        <ion-buttons slot="end">
                            <ion-button onClick="setFavourite(${index})">
                                <ion-icon id="star${index}" name="${star}"></ion-icon>
                            </ion-button> 
                        </ion-buttons>
                    </ion-item>
                
                    <ion-item-options side="end">
                        <ion-item-option onClick="deletePlace(${index})" color="danger">Delete</ion-item-option>
                    </ion-item-options>
                </ion-item-sliding>
            `; 
            }                       

            document.getElementById("list").appendChild(ionList);
        }
    }
    else {
        document.getElementById("list").innerHTML = `
            <ion-item lines="none">No place has yet been saved</ion-item>
            <ion-button href="add.html" expand="block">
                ADD PLACE<ion-icon name="add-outline"></ion-icon>
            </ion-button> 
        `;
    }
}

function deletePlace(index){
    var allPlaces = JSON.parse(localStorage.getItem("allPlaces"));        
   
    allPlaces.splice(index, 1);   

    localStorage.setItem("allPlaces", JSON.stringify(allPlaces));    

    document.getElementById("list").innerHTML = "";

    loadPlaces();

    const toast = document.createElement('ion-toast');
    toast.message = 'Deleted location';
    toast.duration = 1500;

    document.body.appendChild(toast);

    return toast.present();
}

function setFavourite(index){
    var favPlaces = JSON.parse(localStorage.getItem("favPlaces"));
    
    if (favPlaces == null){
        favPlaces = [];
    }        

    favPlaces.push(index);

    favPlaces.sort();

    localStorage.setItem("favPlaces", JSON.stringify(favPlaces));

    document.getElementById("list").innerHTML = "";

    loadPlaces();

    const toast = document.createElement('ion-toast');
    toast.message = 'Added to favourites';
    toast.duration = 1500;

    document.body.appendChild(toast);

    return toast.present();
}

function undoFavourite(index){
    var favPlaces = JSON.parse(localStorage.getItem("favPlaces"));
    
    favPlaces.splice(favPlaces.indexOf(index, 0), 1);

    favPlaces.sort();

    localStorage.setItem("favPlaces", JSON.stringify(favPlaces));

    document.getElementById("list").innerHTML = "";

    loadPlaces();

    const toast = document.createElement('ion-toast');
    toast.message = 'Removed from favourites';
    toast.duration = 1500;

    document.body.appendChild(toast);

    return toast.present();
}

customElements.define('modal-page', class extends HTMLElement {
    connectedCallback() {
        var icon = ``;
        if (modalElement.componentProps.place.category == "Restaurant"){
            icon = `<ion-icon name="restaurant-outline"></ion-icon>`;
        }
        else if(modalElement.componentProps.place.category == "Shop"){
            icon = `<ion-icon name="bag-handle-outline"></ion-icon>`;
        }
        else if(modalElement.componentProps.place.category == "Information"){
            icon = `<ion-icon name="information-outline"></ion-icon>`;
        }
        else if(modalElement.componentProps.place.category == "Leisure"){
            icon = `<ion-icon name="sunny-outline"></ion-icon>`;
        }  
        if (navigator.connection.type == "none"){
            this.innerHTML = `
                <ion-header>
                    <ion-toolbar color="primary">
                        <ion-title color="light">${icon} ${modalElement.componentProps.place.title}</ion-title>
                        <ion-buttons slot="primary">
                            <ion-button onClick="dismissModal()">
                                <ion-icon slot="icon-only" color="light" name="close"></ion-icon>
                            </ion-button>
                        </ion-buttons>
                    </ion-toolbar>
                </ion-header>

                <ion-content class="ion-padding" color="primary">
                    <ion-card>
                        <ion-card-header>
                            <ion-card-title>${icon} ${modalElement.componentProps.place.title}</ion-card-title> 
                            <ion-card-subtitle>${modalElement.componentProps.place.date}</ion-card-subtitle>                          
                        </ion-card-header>
                        
                        <ion-card-content>
                            ${modalElement.componentProps.place.description}
                            <br>
                            <ion-label color="warning">Connect to a network to view your location!</ion-label>
                        </ion-card-content>
                    </ion-card>                   
                </ion-content>
            `;
        }
        else{          
            console.log(modalElement.componentProps);  
            this.innerHTML = `
                <ion-header>
                    <ion-toolbar color="primary">
                        <ion-title color="light">${modalElement.componentProps.place.title}</ion-title>
                        <ion-buttons slot="primary">
                            <ion-button onClick="dismissModal()">
                                <ion-icon slot="icon-only" color="light" name="close"></ion-icon>
                            </ion-button>
                        </ion-buttons>
                    </ion-toolbar>
                </ion-header>

                <ion-content class="ion-padding" color="primary">
                    <ion-card>
                        <div class="map${modalElement.componentProps.index}" style="padding: 150px;"></div>

                        </div>
                        <ion-card-header>
                            <ion-card-title>${icon} ${modalElement.componentProps.place.title}</ion-card-title> 
                            <ion-card-subtitle>${modalElement.componentProps.place.date}</ion-card-subtitle>                          
                        </ion-card-header>
                      
                        <ion-card-content>
                            ${modalElement.componentProps.place.description}
                        </ion-card-content>
                    </ion-card>                    
                </ion-content>
            `;
            getMap(modalElement.componentProps.place.latitude, modalElement.componentProps.place.longitude, modalElement.componentProps.index);
        }        
    }
});

const modalElement = document.createElement('ion-modal');

function presentModal(index) {
    modalElement.component = 'modal-page';

    var allPlaces = JSON.parse(localStorage.getItem("allPlaces"));

    modalElement.componentProps = {
        'place': allPlaces[index],
        "index": index
    }

    document.body.appendChild(modalElement);
    return modalElement.present();
}

function dismissModal() {
    modalElement.dismiss();
}

function getMap(latitude, longitude, index) {
    var mapOptions = {
        center: new google.maps.LatLng(0, 0),
        zoom: 1,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };

    map = new google.maps.Map(document.querySelector(`.map${index}`), mapOptions);

    var latLong = new google.maps.LatLng(latitude, longitude);

    var marker = new google.maps.Marker({
        position: latLong
    });

    marker.setMap(map);
    map.setZoom(15);
    map.setCenter(marker.getPosition());
}

/*   
    if(favPlaces != null || favPlaces != []){  
        favPlaces.forEach(minusOne);
        favPlaces.splice(0, favPlaces.length / 2);
        favPlaces.sort();
        function minusOne(item){
            favPlaces.push(item - 1);
        }
        localStorage.setItem("favPlaces", JSON.stringify(favPlaces)); 
    }
*/