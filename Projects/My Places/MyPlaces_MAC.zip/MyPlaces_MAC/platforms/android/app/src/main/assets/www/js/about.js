document.addEventListener('deviceready', onDeviceReady);

function onDeviceReady() {
    console.log("About is ready");
}