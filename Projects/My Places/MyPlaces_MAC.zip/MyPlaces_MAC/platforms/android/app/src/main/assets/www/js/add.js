document.addEventListener('deviceready', onDeviceReady);

function onDeviceReady() {
    console.log("Add is ready");    
}

function onSuccess(position) {     
    var lat = position.coords.latitude;
    var lon = position.coords.longitude;  

    var axis = JSON.parse(localStorage.getItem("axis"));
    
    axis = [];

    axis.push(lat);
    axis.push(lon);

    localStorage.setItem("axis", JSON.stringify(axis));
}

function savePlace() { 
    navigator.geolocation.getCurrentPosition(onSuccess);
    var titleValue = document.getElementById("title").value; 
    var descriptionValue = document.getElementById("description").value;
    var categoryValue = document.getElementById("category").value;
    var date = new Date();
    var dateValue = date.getDate()+'-'+(date.getMonth()+1)+'-'+date.getFullYear();
    var alert = document.createElement('ion-alert');

    if(titleValue == "" || descriptionValue == ""){
        alert.header = "My Places"
        alert.message = "All fields have to be filled in"
        alert.buttons = [
            {
                text: 'Ok',
                role: 'cancel'
            }
        ]

        document.body.appendChild(alert);
    }
    else{
        alert.header = "My Places"
        alert.message = "Are you sure you want to save this place?"
        alert.buttons = [
            {
                text: 'Cancel',
                role: 'cancel'
            },
            {
                text: 'Ok',
                handler: () => {
                    var axis = JSON.parse(localStorage.getItem("axis"));

                    var place = {
                        "title": titleValue,
                        "description": descriptionValue,
                        "category": categoryValue,
                        "latitude": axis[0],
                        "longitude": axis[1],                        
                        "date": dateValue
                    };
                
                    var places = JSON.parse(localStorage.getItem("allPlaces"));
                    if (places == null)
                        places = [];
                
                    places.push(place);
                
                    localStorage.setItem("allPlaces", JSON.stringify(places));

                    const toast = document.createElement('ion-toast');
                    toast.message = 'Your location has been saved';
                    toast.duration = 1500;

                    document.body.appendChild(toast);
                    
                    window.location.href = "index.html";

                    return toast.present();
                }
            }
        ]

        document.body.appendChild(alert);        
    }    
    return alert.present();
}