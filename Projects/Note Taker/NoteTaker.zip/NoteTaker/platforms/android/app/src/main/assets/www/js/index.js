// Wait for the deviceready event before using any of Cordova's device APIs.
// See https://cordova.apache.org/docs/en/latest/cordova/events/events.html#deviceready
document.addEventListener('deviceready', onDeviceReady);

function onDeviceReady() {
    console.log('Running cordova-' + cordova.platformId + '@' + cordova.version);

    saveBtn = document.getElementById("saveBtn");
    saveBtn.addEventListener("click", saveNote);

    var deleteBtn = document.getElementById("deleteBtn");
    deleteBtn.addEventListener("click", deleteAllNotes);
}

function saveNote() {     
    var titleValue = document.getElementById("title").value; 
    var whenValue = document.getElementById("when").value;
    var alert = document.createElement('ion-alert');

    if(titleValue == "" || whenValue == ""){
        alert.header = "Note Taker"
        alert.message = "Please fill in both the title and the when field"
        alert.buttons = [
            {
                text: 'Ok',
                role: 'cancel'
            }
        ]

        document.body.appendChild(alert);
    }
    else{
        alert.header = "Note Taker"
        alert.message = "Are you sure you want to save this note?"
        alert.buttons = [
            {
                text: 'Cancel',
                role: 'cancel'
            },
            {
                text: 'Ok',
                handler: () => {
                    var note = {
                        "title": titleValue,
                        "when": whenValue
                    };
                
                    var notes = JSON.parse(localStorage.getItem("Notes"));
                    if (notes == null)
                        notes = [];
                
                    notes.push(note);
                
                    localStorage.setItem("Notes", JSON.stringify(notes));

                    document.getElementById("tab-button-tab-list").click();

                    const toast = document.createElement('ion-toast');
                    toast.message = 'Your note was saved';
                    toast.duration = 1500;

                    document.body.appendChild(toast);
                    return toast.present();
                }
            }
        ]

        document.body.appendChild(alert);        
    }    
    return alert.present();
}

function loadNotes(){
    var Notes = JSON.parse(localStorage.getItem("Notes"));
    var output = document.getElementById("outputDiv");
    if(Notes != null && Notes.length > 0){        
        output.innerHTML = "";
        Notes.forEach(addNoteToOutput);

        function addNoteToOutput(note, index){
            const ionItem = document.createElement('ion-item');
            ionItem.setAttribute("lines", "full");

            ionItem.innerHTML += `
                                    <ion-label class="labelMessage" data="${index}">
                                        <h2>${note.title}</h2>
                                        <p>${note.when}</p>
                                    </ion-label>
                                `;

            ionItem.innerHTML += `<ion-icon class="deleteMessageIcon" name="trash-outline" slot="end" data="${index}" onClick="deleteNote(this)"></ion-icon>`;

            document.getElementById("outputDiv").appendChild(ionItem);
        }
    }
    else{
        output.innerHTML = "<ion-item lines='full'><ion-label>No notes yet.</ion-label></ion-item>";
    }
}

function deleteAllNotes(){
    var alert = document.createElement('ion-alert');
    
    alert.header = 'Delete all notes';
    alert.message = 'Are you sure you want to delete all the notes?';
    alert.buttons = [
        {
            text: 'No',
            role: 'cancel'
        },
        {
            text: "Yes",
            handler: () => {
                localStorage.removeItem("Notes");

                loadNotes();

                const toast = document.createElement('ion-toast');
                toast.message = 'All notes were cleared';
                toast.duration = 1500;

                document.body.appendChild(toast);
                return toast.present();
            }
        }
    ];

    document.body.appendChild(alert);

    return alert.present();
}

function deleteNote(note){
    var allNotes = JSON.parse(localStorage.getItem("Notes"));

    allNotes.splice(note.getAttribute("data"), 1);

    localStorage.setItem("Notes", JSON.stringify(allNotes));

    loadNotes();

    const toast = document.createElement('ion-toast');
    toast.message = 'Your note has been deleted';
    toast.duration = 1500;

    document.body.appendChild(toast);
    return toast.present();
}